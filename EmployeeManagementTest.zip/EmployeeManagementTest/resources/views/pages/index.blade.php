@extends('layouts.master')

@section('title', 'Dashboard')

@section('content')
<div class="container-fluid" id="container-wrapper">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">All Employees</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="./">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        </ol>
    </div>

    <div class="row">
        <!-- Datatables -->
        <div class="col-lg-12">
            @if(Session::has('success'))
            <div class="alert alert-success" role="alert">
                {{Session::get('success')}}
            </div>
            @endif

            @if(Session::has('error'))
            <div class="alert alert-danger" role="alert">
                {{Session::get('error')}}
            </div>
            @endif
            <div class="card mb-4">

                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">All Students Marks</h6>
                </div>

                <div class="table-responsive p-3">
                    <table class="table align-items-center table-flush" id="dataTable">
                        <thead class="thead-light">
                            <tr>
                                <th>S.no</th>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Designation</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            @foreach($employees as $key => $employee)

                            <tr>
                                <td>{{ $key+1 }}</td>
                                <td><img src="{{ Storage::url('public/images/'.$employee->photo) }}" alt="img" style="height: 50px;width:auto;"></td>
                                <td>{{ $employee->name }}</td>
                                <td>{{ $employee->email }}</td>
                                <td>{{ $employee->designations->designation }}</td>

                                <td style="display:flex">
                                    <a title="Edit" href="{{route('editEmployee',[$employee->id])}}" class="btn btn-primary">Edit</a>&nbsp;
                                    <a class="btn btn-danger" onclick="event.preventDefault();document.getElementById('delete-form{{ $employee->id }}').submit();">
                                        <i class="fas fa-trash" style="color: #fff;"></i>
                                    </a>
                                    <form action="{{ route('deleteEmployee',[ $employee->id ]) }}" id="delete-form{{ $employee->id }}" method="post">
                                        {{method_field('DELETE')}}
                                        @csrf</form>
                                </td>
                            </tr>

                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


    </div>



</div>

@endsection
