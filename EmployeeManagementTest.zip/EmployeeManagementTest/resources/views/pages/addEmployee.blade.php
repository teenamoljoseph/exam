@extends('layouts.master')

@section('title', 'Add Employee')


@section('content')
<div class="container-fluid" id="container-wrapper">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">Add Employee</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="#">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Add Employee</li>
        </ol>
    </div>

    <div class="row">
        <div class="col-lg-12">
            <!-- Form Basic -->
            <div class="card">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">Add Employee</h6>
                </div>
                <div class="card-body">
                    <form method="POST" action="{{ route('saveEmployee') }}" enctype="multipart/form-data">@csrf
                        <div class="form-group col-md-6">
                            <label for="ename">Employee Name</label>
                            <input type="text" class="form-control @error('ename') is-invalid @enderror" id="ename" name="ename" placeholder="Employee Name" value="{{ old('ename') }}">
                            @error('ename')
                            <span class="text-danger">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                        <div class="form-group col-md-6">
                            <label for="email">Email</label>
                            <input type="email" name="email" class="form-control @error('email') is-invalid @enderror" id="email" value="{{ old('email') }}" placeholder="Email">
                            @error('email')
                            <span class="text-danger">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>

                        <div class="form-group col-md-6">
                            <label for="gender">Designation</label>
                            <select class="form-control @error('designation') is-invalid @enderror" name="designation">
                                <option value="">Select Designation</option>
                                @foreach(App\Models\Designation::all() as $key=> $designation)
                                <option value=" {{$designation->id}}">{{$designation->designation}}</option>
                                @endforeach

                            </select>
                            @error('designation')
                            <span class="text-danger">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>

                        <div class="form-group col-md-6">
                            <label for="gender">Upload Photo</label>
                            <input type="file" name="image" id="image" />
                            @error('image')
                            <span class="text-danger">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>



                        <div class="form-group col-md-6">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>



                    </form>
                </div>
            </div>


        </div>


    </div>


</div>
@endsection
