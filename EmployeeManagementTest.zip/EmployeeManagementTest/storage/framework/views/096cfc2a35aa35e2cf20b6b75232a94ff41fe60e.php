

<?php $__env->startSection('title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid" id="container-wrapper">
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-800">All Employees</h1>
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="./">Home</a></li>
            <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
        </ol>
    </div>

    <div class="row">
        <!-- Datatables -->
        <div class="col-lg-12">
            <?php if(Session::has('success')): ?>
            <div class="alert alert-success" role="alert">
                <?php echo e(Session::get('success')); ?>

            </div>
            <?php endif; ?>

            <?php if(Session::has('error')): ?>
            <div class="alert alert-danger" role="alert">
                <?php echo e(Session::get('error')); ?>

            </div>
            <?php endif; ?>
            <div class="card mb-4">

                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h6 class="m-0 font-weight-bold text-primary">All Students Marks</h6>
                </div>

                <div class="table-responsive p-3">
                    <table class="table align-items-center table-flush" id="dataTable">
                        <thead class="thead-light">
                            <tr>
                                <th>S.no</th>
                                <th>Photo</th>
                                <th>Name</th>
                                <th>Email</th>
                                <th>Designation</th>
                                <th>Action</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $employees; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $employee): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <tr>
                                <td><?php echo e($key+1); ?></td>
                                <td><img src="<?php echo e(Storage::url('public/images/'.$employee->photo)); ?>" alt="img" style="height: 50px;width:auto;"></td>
                                <td><?php echo e($employee->name); ?></td>
                                <td><?php echo e($employee->email); ?></td>
                                <td><?php echo e($employee->designations->designation); ?></td>

                                <td style="display:flex">
                                    <a title="Edit" href="<?php echo e(route('editEmployee',[$employee->id])); ?>" class="btn btn-primary">Edit</a>&nbsp;
                                    <a class="btn btn-danger" onclick="event.preventDefault();document.getElementById('delete-form<?php echo e($employee->id); ?>').submit();">
                                        <i class="fas fa-trash" style="color: #fff;"></i>
                                    </a>
                                    <form action="<?php echo e(route('deleteEmployee',[ $employee->id ])); ?>" id="delete-form<?php echo e($employee->id); ?>" method="post">
                                        <?php echo e(method_field('DELETE')); ?>

                                        <?php echo csrf_field(); ?></form>
                                </td>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>


    </div>



</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\EmployeeManagementTest\resources\views/pages/index.blade.php ENDPATH**/ ?>