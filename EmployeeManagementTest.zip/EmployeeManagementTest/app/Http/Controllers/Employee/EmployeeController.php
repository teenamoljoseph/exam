<?php

namespace App\Http\Controllers\Employee;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Employee;
use Illuminate\Support\Facades\Storage;
use PHPMailer\PHPMailer\PHPMailer;


class EmployeeController extends Controller
{
    public function addEmployee(){
        return view('pages.addEmployee');
    }

    public function saveEmployee(Request $request){
        $this->validate($request,[
            'ename'=>'required',
            'email'=>'required|unique:employees,email',
            'image'=>'required|max:6144',
            'designation'=>'required',
            
          ],[
             'ename.required'=>'Employee Name Required !',
             'email.required'=>'Email Required !',
             'email.unique'=>'Email must be unique !',
             'image.required'=>'Employee Photo Required !',
             'image.max'=>'Maximum File Size 6 MB !',
             'image.mimes'=>'Support Only png,jpg,jpeg',
             'designation.required'=>'Designation Required',
           
          ]);

          
       
          $employee=new Employee();
          $employee->name=$request->ename;
          $employee->email=$request->email;
          $employee->designation=$request->designation;
          if($request->hasFile('image'))
          {
              $imageName = time().'.'.$request->image->extension();
              $request->image->storeAs('public/images', $imageName);
              $employee->photo=$imageName;
               
          }
         $save=$employee->save();
         

          if($save){
            require base_path("vendor/autoload.php");
            $mail = new PHPMailer();     // Passing `true` enables exceptions
    
                // Email server settings
                $mail->SMTPDebug = 0;
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';             //  smtp host
                $mail->SMTPAuth = true;
                $mail->Username = 'jacksonsimethyaj@gmail.com';   //  sender username
                $mail->Password = 'aj@iloveme1997';       // sender password
                $mail->SMTPSecure = 'tls';                  // encryption - ssl/tls
                $mail->Port = 587;                          // port - 587/465
    
                $mail->setFrom('jacksonsimethyaj@gmail.com', 'Employee Management');
                $mail->addAddress($request->email);
                $mail->isHTML(true);                // Set email content format to HTML
                $mail->Subject = 'Employee Management';
                $mail->Body    = '<h1>Your account has been  created successfully !</h1>
            
                <p>You are password:-'.rand(0,99999).' </p>';
                // $mail->AltBody = plain text version of email body;
    
                $mail->send();
          
            
            return redirect()->route('home')->with('success','Employee Added..');
        }else{

            return redirect()->route('home')->with('error','Error in Employee Adding..');
        }

    }

   public function editEmployee($id){
       $employee=Employee::find($id);
       return view('pages.editEmployee',compact('employee'));
   }

   public function updateEmployee(Request $request,$id){
         $employee=Employee::find($id);
        
         $this->validate($request,[
            'ename'=>'required',
            'email'=>'required|unique:employees,email,'.$id,
            'image'=>'max:6144',
            'designation'=>'required',
            
          ],[
             'ename.required'=>'Employee Name Required !',
             'email.required'=>'Email Required !',
             'email.unique'=>'Email must be unique !',
            
             'image.max'=>'Maximum File Size 6 MB !',
             'image.mimes'=>'Support Only png,jpg,jpeg',
             'designation.required'=>'Designation Required',
           
          ]);

          
          $employee->name=$request->ename;
          $employee->email=$request->email;
          $employee->designation=$request->designation;
          if($request->hasFile('image'))
          {
              $imageName = time().'.'.$request->image->extension();
              $request->image->storeAs('public/images', $imageName);
              $employee->photo=$imageName;
               
          }else{
              $employee->photo=$employee->photo;
          }
         $save=$employee->save();

          if($save){
            
            return redirect()->route('home')->with('success','Employee Details Updated..');
        }else{

            return redirect()->route('home')->with('error','Error in Employee Updating..');
        }
   }

   public function deleteEmployee($id){
    $employee=Employee::find($id);
    Storage::delete('public/images/'.$employee->photo);
    $delete=$employee->delete();
    
    if($delete){
            
        return redirect()->route('home')->with('success','Employee Removed..');
    }else{

        return redirect()->route('home')->with('error','Error in Removing Employee..');
    }
   }
}