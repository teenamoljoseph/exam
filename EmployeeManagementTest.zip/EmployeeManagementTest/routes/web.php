<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\HomeController;
use App\Http\Controllers\Employee\EmployeeController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',[HomeController::class,'home'])->name('home');
Route::get('/add-employee',[EmployeeController::class,'addEmployee'])->name('addEmployee');
Route::post('/save-employee',[EmployeeController::class,'saveEmployee'])->name('saveEmployee');
Route::get('/edit-employee/{id}',[EmployeeController::class,'editEmployee'])->name('editEmployee');
Route::put('/update-employee/{id}',[EmployeeController::class,'updateEmployee'])->name('updateEmployee');
Route::delete('/delete-employee/{id}',[EmployeeController::class,'deleteEmployee'])->name('deleteEmployee');
      