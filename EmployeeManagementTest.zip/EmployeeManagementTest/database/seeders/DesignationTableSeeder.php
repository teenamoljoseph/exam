<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DesignationTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        \App\Models\Designation::create([
          'designation'=>'Sales Executive'
        ]);

        \App\Models\Designation::create([
            'designation'=>'Admin'
          ]);

        \App\Models\Designation::create([
            'designation'=>'Software Developer'
          ]);
    }
}